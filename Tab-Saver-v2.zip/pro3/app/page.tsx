"use client"

import  from "../popup"

export default function SyntheticV0PageForDeployment() {
  return < />
}
